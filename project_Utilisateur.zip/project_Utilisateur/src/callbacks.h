#include <gtk/gtk.h>


void
on_button1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mod_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_check_id_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_button_aj_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_button5_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_button_alarme_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data);


void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data);


void
on_button14_ajout_k_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button12_modifier_k_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button13_recherche_k_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button10_supprimer_k_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button15_mouv_k_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_af_k_clicked                 (GtkButton       *button,
                                        gpointer         user_data);


void
on_treeview_utilisateur_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button6_k_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_valide_k_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_check_id_k_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modvalid_k_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button8_k_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercher_k_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button7_k_clicked                   (GtkButton       *button,
                                        gpointer         user_data);


